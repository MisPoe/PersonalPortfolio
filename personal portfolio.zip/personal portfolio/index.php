<?php

$conn = mysqli_connect('localhost','root','','contact_db') or die('connection failed');

if(isset($_POST['send'])){

   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $number = mysqli_real_escape_string($conn, $_POST['number']);
   $msg = mysqli_real_escape_string($conn, $_POST['message']);

   $select_message = mysqli_query($conn, "SELECT * FROM `contact_form` WHERE name = '$name' AND email = '$email' AND number = '$number' AND message = '$msg'") or die('query failed');
   
   if(mysqli_num_rows($select_message) > 0){
      $message[] = 'message sent already!';
   }else{
      mysqli_query($conn, "INSERT INTO `contact_form`(name, email, number, message) VALUES('$name', '$email', '$number', '$msg')") or die('query failed');
      $message[] = 'message sent successfully!';
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Complete Responsive Personal Portfolio Website Design</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css">

   <!-- aos css link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>

<?php

if(isset($message)){
   foreach($message as $message){
      echo '
      <div class="message" data-aos="zoom-out">
         <span>'.$message.'</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
      ';
   }
}

?>

<!-- header section starts  -->

<header class="header">

   <div id="menu-btn" class="fas fa-bars"></div>

   <a href="#home" class="logo">Portfolio</a>

   <nav class="navbar">
      <a href="#home" class="active">home</a>
      <a href="#about">about</a>
      <a href="#services">services</a>
      <a href="#portfolio">portfolio</a>
      <a href="#contact">contact</a>
   </nav>

   <div class="follow">
      <a href="#" class="fab fa-facebook-f"></a>
      <a href="#" class="fab fa-twitter"></a>
      <a href="#" class="fab fa-instagram"></a>
      <a href="https://www.linkedin.com/in/poe-ei-phyu-6bb7941a4/" class="fab fa-linkedin"></a>
      <a href="http://localhost/personal%20portfolio/index.php" class="fab fa-github"></a>
   </div>

</header>

<!-- header section ends -->

<!-- home section starts  -->

<section class="home" id="home">

   <div class="image" data-aos="fade-right">
      <img src="images/my.jpg" alt="">
   </div>

   <div class="content">
      <h3 data-aos="fade-up">hi, i am Poe ei phyu</h3>
      <span data-aos="fade-up">web developer</span>
      <p data-aos="fade-up">I have created over a dozen websites and web applications for my academic learning journeys. I am curious to learn new things, and I am always looking for a new challenge. I gathered my first experience learning and developing in academic mini-projects. 0nce my project has become a unique product, one of my happiest moments, and if I say I'm passionate about it, it would be my passion for developing and managing websites.</p>
      <a data-aos="fade-up" href="#about" class="btn">about me</a>
   </div>

</section>

<!-- home section ends -->

<!-- about section starts  -->

<section class="about" id="about">

   <h1 class="heading" data-aos="fade-up"> <span>biography</span> </h1>

   <div class="biography">

      <p data-aos="fade-up">I am equipped with a diverse and promising skill-set and I am proficient in various technologies, including HTML, CSS, JavaScript, Java, Spring Boot, React JS, Apache Tomcat, MySQL Server, and databases. </p>

      <div class="bio">
         <h3 data-aos="zoom-in"> <span>name : </span>  Poe Ei Phyu</h3>
         <h3 data-aos="zoom-in"> <span>email : </span> poeeiphyu171997@gmail.com </h3>
         <h3 data-aos="zoom-in"> <span>address : </span> Yangon, Myanmar </h3>
         <h3 data-aos="zoom-in"> <span>phone : </span> +959979709348 </h3>
      </div>

      <a href="#" class="btn" data-aos="fade-up">download CV</a>

   </div>
   
   <div class="skills" data-aos="fade-up">

      <h1 class="heading"> <span>skills</span> </h1>

      <div class="progress">
         <div class="bar" data-aos="fade-left"> <h3><span>HTML</span> <span>95%</span></h3> </div>
         <div class="bar" data-aos="fade-right"> <h3><span>CSS</span> <span>80%</span></h3> </div>
         <div class="bar" data-aos="fade-left"> <h3><span>JavaScript</span> <span>65%</span></h3> </div>
         <div class="bar" data-aos="fade-right"> <h3><span>PHP</span> <span>80%</span></h3> </div>
         <div class="bar" data-aos="fade-left"> <h3><span>JAVA</span> <span>80%</span></h3> </div>
         <div class="bar" data-aos="fade-right"> <h3><span>Spring Boot</span> <span>80%</span></h3> </div>
         <div class="bar" data-aos="fade-left"> <h3><span>Database</span> <span>90%</span></h3> </div>
         <div class="bar" data-aos="fade-right"> <h3><span>Project Management</span> <span>80%</span></h3> </div>
      </div>

   </div>

   <div class="edu-exp">

      <h1 class="heading" data-aos="fade-up"> <span>education & experience</span> </h1>

      <div class="row">

         <div class="box-container">

            <h3 class="title" data-aos="fade-right">education</h3>

            <div class="box" data-aos="fade-right">
               <span>( 2014 - 2018 )</span>
               <h3>L.L B (Bachelor of Law)</h3>
               <p>L.L B (Bachelor of Law) at Dagon University (Myanmar)</p>
            </div>

            <div class="box" data-aos="fade-left">
               <span>( 2019 - 2021 )</span>
               <h3>Level 3 (HND Diplama in Computing)</h3>
               <p>Level 3 (HND Diplama in Computing) at Lithan University Collage</p>
            </div>

            <div class="box" data-aos="fade-right">
               <span>( May, 2021 - Dec, 2021 )</span>
               <h3>Level 4 (HND Diplama in Computing)</h3>
               <p>Level 4 (HND Diplama in Computing) at Lithan University Collage</p>
            </div>

            <div class="box" data-aos="fade-left">
               <span>( Jan, 2022 - Dec, 2022 )</span>
               <h3>Level 5 (HND Diplama in Computing)</h3>
               <p>Level 5 (HND Diplama in Computing) at Lithan University Collage</p>
            </div>
            



         

   </div>

</section>

<!-- about section ends -->

<!-- services section starts  -->

<section class="services" id="services">

   <h1 class="heading" data-aos="fade-up"> <span>services</span> </h1>

   <div class="box-container">

      <div class="box" data-aos="zoom-in">
         <i class="fas fa-code"></i>
         <h3>web development</h3>
      </div>

      <div class="box" data-aos="zoom-in">
         <i class="fab fa-bootstrap"></i>
         <h3>bootstrap</h3>
        
      </div>
      <div class="box" data-aos="zoom-in">
         <i class="fab fa-wordpress"></i>
         <h3>wordpress</h3>
         

   </div>

</section>

<!-- services section ends -->

<!-- portfolio section starts  -->

<section class="portfolio" id="portfolio">

   <h1 class="heading" data-aos="fade-up"> <span>Academic Project</span> </h1>

   <div class="box-container">

      <div class="box" data-aos="zoom-in">
      <a href="https://github.com/MisPoe"><img src="images/img1.png" alt="">
         <h3>Existing Login API by using Spring Boot and React JS</h3>
         <span>( 2022 )</span></a>
      </div>

      <div class="box" data-aos="zoom-in">
      <a href="https://github.com/MisPoe"><img src="images/1.png" alt="">
         <h3>Car Portal by using Spring Security</h3>
         <span>(2022 )</span></a>
      </div>

      <div class="box" data-aos="zoom-in">
      <a href="https://github.com/MisPoe"><img src="images/2.png" alt="">
         <h3>Job Portal by using Struts2CRUD</h3>
         <span>( 2021)</span></a>
      </div>

      <div class="box" data-aos="zoom-in">
         <img src="images/3.png" alt="">
         <h3>Knows_Yours_Neighborhoods_Application by using Spring Boot</h3>
         <span>( 2022 )</span>
      </div>

      <div class="box" data-aos="zoom-in">
         <img src="images/4.png" alt="">
         <h3>Project Management for Remote Working Solution</h3>
         <span>( 2021 )</span>
      </div>

      <div class="box" data-aos="zoom-in">
         <img src="images/5.png" alt="">
         <h3>Project Management & Developemt for Digital Transformation</h3>
         <span>( 2022 )</span>
      </div>

   </div>

</section>

<!-- portfolio section ends -->

<!-- contact section starts  -->

<section class="contact" id="contact">

   <h1 class="heading" data-aos="fade-up"> <span>contact me</span> </h1>

   <form action="" method="post">
      <div class="flex">
         <input data-aos="fade-right" type="text" name="name" placeholder="enter your name" class="box" required>
         <input data-aos="fade-left" type="email" name="email" placeholder="enter your email" class="box" required>
      </div>
      <input data-aos="fade-up" type="number" min="0" name="number" placeholder="enter your number" class="box" required>
      <textarea data-aos="fade-up" name="message" class="box" required placeholder="enter your message" cols="30" rows="10"></textarea>
      <input type="submit" data-aos="zoom-in" value="send message" name="send" class="btn">
   </form>

   <div class="box-container">

      <div class="box" data-aos="zoom-in">
         <i class="fas fa-phone"></i>
         <h3>phone</h3>
         <p>+959979709348</p>
      </div>

      <div class="box" data-aos="zoom-in">
         <i class="fas fa-envelope"></i>
         <h3>email</h3>
         <p>poeeiphyu171997@gmail.com</p>
      </div>

      <div class="box" data-aos="zoom-in">
         <i class="fas fa-map-marker-alt"></i>
         <h3>address</h3>
         <p>Yangon, Myanmar</p>
      </div>

   </div>

</section>

<!-- contact section ends -->

<div class="credit"> &copy; copyright @ <?php echo date('Y'); ?> by <span>Poe Ei Phyu</span> </div>












<!-- custom js file link  -->
<script src="js/script.js"></script>

<!-- aos js link  -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>

<script>

   AOS.init({
      duration:800,
      delay:300
   });

</script>
   
</body>
</html>